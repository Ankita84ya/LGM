function e()
{
 Calculator.Input.value=eval(Calculator.Input.value);
}